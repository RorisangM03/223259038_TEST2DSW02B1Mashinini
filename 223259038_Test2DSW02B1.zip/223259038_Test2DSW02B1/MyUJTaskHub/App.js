import React from "react";
import TaskScreen from "./src/screens/TaskScreen";
import globalStyles from "../styles/globalStyles";

export default function App() {
  return <TaskScreen />;
}