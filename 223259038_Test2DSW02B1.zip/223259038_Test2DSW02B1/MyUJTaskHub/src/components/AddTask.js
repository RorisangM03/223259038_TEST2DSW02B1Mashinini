import React, { useState } from "react";
import { View, TextInput, Button, Picker, StyleSheet } from "react-native";
import globalStyles from "../styles/globalStyles";

export default function AddTask({ onAdd }) {
  const [title, setTitle] = useState("");
  const [priority, setPriority] = useState("Low");

  const handleAdd = () => {
    if (title.trim() === "") return;
    onAdd({ title, priority });
    setTitle("");
    setPriority("Low");
  };

  return (
    <View style={styles.container}>
      <TextInput
        placeholder="Enter task"
        value={title}
        onChangeText={setTitle}
        style={styles.input}
      />
      <Picker selectedValue={priority} onValueChange={setPriority}>
        <Picker.Item label="Low" value="Low" />
        <Picker.Item label="Medium" value="Medium" />
        <Picker.Item label="High" value="High" />
      </Picker>
      <Button title="Add Task" onPress={handleAdd} />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { margin: 10 },
  input: { borderWidth: 1, padding: 8, marginBottom: 8 }
});