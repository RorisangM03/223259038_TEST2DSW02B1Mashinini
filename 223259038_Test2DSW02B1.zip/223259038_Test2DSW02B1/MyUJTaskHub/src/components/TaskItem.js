import React from "react";
import { View, Text, TouchableOpacity, StyleSheet } from "react-native";
import globalStyles from "../styles/globalStyles";

export default function TaskItem({ task, onToggle, onDelete }) {
  return (
    <View style={styles.container}>
      <Text style={[styles.text, task.completed && styles.completed]}>
        {task.title} ({task.priority})
      </Text>
      <View style={styles.actions}>
        <TouchableOpacity onPress={() => onToggle(task)}>
          <Text style={styles.button}>
            {task.completed ? "Reopen" : "Complete"}
          </Text>
        </TouchableOpacity>
        <TouchableOpacity onPress={() => onDelete(task.id)}>
          <Text style={[styles.button, styles.delete]}>Delete</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flexDirection: "row", justifyContent: "space-between", margin: 8 },
  text: { fontSize: 16 },
  completed: { textDecorationLine: "line-through", color: "green" },
  actions: { flexDirection: "row" },
  button: { marginHorizontal: 8, color: "blue" },
  delete: { color: "red" }
});