import React from "react";
import { View, Text, Button, FlatList } from "react-native";
import { useApp } from "../context/AppContext";

const services = [
  { id: "1", name: "Library Support" },
  { id: "2", name: "ICT Helpdesk" },
  { id: "3", name: "Academic Consultation" },
  { id: "4", name: "Career Services" }
];

export default function ServiceScreen() {
  const { savedServices, addSavedService, removeSavedService } = useApp();

  const isSaved = (id) => savedServices.some((s) => s.id === id);

  return (
    <View style={{ flex: 1, padding: 20 }}>
      <FlatList
        data={services}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <View style={{ marginVertical: 10 }}>
            <Text>{item.name}</Text>
            {isSaved(item.id) ? (
              <Button title="Remove" onPress={() => removeSavedService(item.id)} />
            ) : (
              <Button title="Save" onPress={() => addSavedService(item)} />
            )}
          </View>
        )}
      />
    </View>
  );
}