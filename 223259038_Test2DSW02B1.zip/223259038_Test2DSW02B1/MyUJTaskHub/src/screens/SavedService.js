import React from "react";
import { View, Text, FlatList } from "react-native";
import { useApp } from "../context/AppContext";

export default function SavedService() {
  const { savedServices } = useApp();

  if (savedServices.length === 0) {
    return (
      <View style={{ flex: 1, justifyContent: "center", alignItems: "center" }}>
        <Text>No saved services yet.</Text>
      </View>
    );
  }

  return (
    <View style={{ flex: 1, padding: 20 }}>
      <FlatList
        data={savedServices}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <View style={{ marginVertical: 10 }}>
            <Text>{item.name}</Text>
          </View>
        )}
      />
    </View>
  );
}