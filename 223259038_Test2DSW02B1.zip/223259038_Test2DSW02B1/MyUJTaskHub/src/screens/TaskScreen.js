import React, { useEffect, useState } from "react";
import { View, FlatList, Text, ActivityIndicator } from "react-native";
import { db } from "../services/firebase";
import { collection, addDoc, onSnapshot, updateDoc, doc, deleteDoc } from "firebase/firestore";
import TaskItem from "../components/TaskItem";
import AddTask from "../components/AddTask";
import globalStyles from "../styles/globalStyles";

export default function TaskScreen() {
  const [tasks, setTasks] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const unsubscribe = onSnapshot(collection(db, "tasks"), (snapshot) => {
      const list = snapshot.docs.map((doc) => ({
        id: doc.id,
        ...doc.data()
      }));
      setTasks(list);
      setLoading(false);
    });
    return () => unsubscribe();
  }, []);

  const addTask = async ({ title, priority }) => {
    await addDoc(collection(db, "tasks"), {
      title,
      priority,
      completed: false
    });
  };

  const toggleTask = async (task) => {
    const ref = doc(db, "tasks", task.id);
    await updateDoc(ref, { completed: !task.completed });
  };

  const deleteTask = async (id) => {
    await deleteDoc(doc(db, "tasks", id));
  };

  if (loading) return <ActivityIndicator size="large" />;

  if (tasks.length === 0) return <Text>No tasks yet</Text>;

  return (
    <View style={{ flex: 1, padding: 20 }}>
      <AddTask onAdd={addTask} />
      <FlatList
        data={tasks}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <TaskItem task={item} onToggle={toggleTask} onDelete={deleteTask} />
        )}
      />
    </View>
  );
}