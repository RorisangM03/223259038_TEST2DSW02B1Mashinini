import React from "react";
import { View, Text, Button } from "react-native";
import { useApp } from "../context/AppContext";

export default function HomeScreen({ navigation }) {
  const { savedServices, theme, setTheme } = useApp();

  return (
    <View style={{ flex: 1, justifyContent: "center", alignItems: "center" }}>
      <Text>Saved Services: {savedServices.length}</Text>
      <Text>Current Theme: {theme}</Text>
      <Button
        title="Toggle Theme"
        onPress={() => setTheme(theme === "light" ? "dark" : "light")}
      />
      <Button title="Go to Services" onPress={() => navigation.navigate("Services")} />
      <Button title="Go to Saved Services" onPress={() => navigation.navigate("SavedServices")} />
    </View>
  );
}