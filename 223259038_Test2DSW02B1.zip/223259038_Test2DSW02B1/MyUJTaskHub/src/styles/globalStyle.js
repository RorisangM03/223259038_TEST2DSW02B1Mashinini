import { StyleSheet } from "react-native";
import globalStyles from "../styles/globalStyles";

const globalStyles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    backgroundColor: "#f9f9f9"
  },
  input: {
    borderWidth: 1,
    borderColor: "#ccc",
    borderRadius: 5,
    padding: 10,
    marginBottom: 10,
    backgroundColor: "#fff"
  },
  button: {
    padding: 10,
    backgroundColor: "#007bff",
    borderRadius: 5,
    alignItems: "center",
    marginVertical: 5
  },
  buttonText: {
    color: "#fff",
    fontWeight: "bold"
  },
  title: {
    fontSize: 20,
    fontWeight: "bold",
    marginBottom: 10
  },
  errorText: {
    color: "red",
    marginVertical: 5
  },
  emptyText: {
    color: "#555",
    fontStyle: "italic",
    textAlign: "center",
    marginTop: 20
  }
});

export default globalStyles;